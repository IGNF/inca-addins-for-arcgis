#######################################
# Config file (TEMPLATE)		      #
#######################################


#######################################
Le fichier "maplex_engine_config_file_TEMPLATE.xlsx" contient quelques exemples de paramétrage afin de guider un peu mieux à l'utilisateur qui se sert de l'outil pour la première fois.

------------
--- NOTE ---
------------
Etant donné que l'outil commence à lire les valeurs renseignées juste après les noms de colonnes, les 2 premières colonnes avant les exemples de paramétrage (les types de données et la ligne noire) doivent être éffacées si vous voulez adapter ce template dans un environnement de production. Si vous ne le faites pas l'outil marchera de toute façon, mais il va enregistrer des erreurs futiles dans le fichier de logs.



#######################################
Le fichier "cast_features_rules_file_TEMPLATE.xlsx" contient quelques exemples de paramétrages afin de guider l'utilisateur pour le paramétrage de l'outil de transtypage (CastFeature)



#######################################
Le dossier zip "ICON_ODG.zip" contient un paramétrage pour la chaine 25K. Il peut servir de template pour créer son propore fichier de paramétrage pour l'outil jeux d'attributs (AttibuteSets)