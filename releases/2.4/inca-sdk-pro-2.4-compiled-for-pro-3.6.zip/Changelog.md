
# Package Addins SDK INCA - Release notes

## ------------------------
## Release 2.4 - 05/11/2026
### 1. Nouvelles fonctionalités
- Nouvel outil d’update des réplicas
- Nouvel outil de gestions des conflits pouvant survenir entre la géodatabase d'extraction et la géodatabase partagée lors de l'Update.
Une interface permet de visualiser et de résoudre les conflits.
- Nouvel outil de mise à jour des symboles de texte des annotations (Update symbols)

### 2. Corrections et Améliorations  
<u>Outils Jeux d'attributs</u> : mise à jour du fichier JeuxAttributsINCA-25K_ODG.btn.xml pour intégrer de nouveaux boutons qui permettent de coder offsetside et offestdist

<u>Transtypage</u> : prise en compte des valeurs d’attribut renseignées entité par entité (override) (Amelio 2026060284)

<u>Outil changement de côté du décalage</u> : ajout d’une option pour réaligner la géométrie d'une entité sur un linéaire de référence sans changement de côté (Redmine 21382)

<u>Outil de réintégration des réplicas</u> :  
    *&emsp;gestion fichier replica.txt vide ou mauvaise structure + gestion bug synchro incomplète  
    *&emsp;prise en compte du warning 160370 "The version has been redefined to reference a new database state"  
    *&emsp;Récupération message synchronisation KO + bouton exécuté grisé pendant l'opération  
    *&emsp;Amelio 2026082518 : message d'avertissement avant réintégration si mise à jour en cours  
    *&emsp;Édition désactivée qui bloque le changement de résolution des conflits

<u>Menu d’export des symboles</u> : possibilité d'exporter les symboles de texte d'une ou plusieurs couches d'annotations dans un fichier .stylx

<u>Outil encadrés des toponymes</u> : [Amelio 2026100300] : Correction sur les calculs d'encadrés des toponymes transtypés de INCA vers F25

Ajout de la <u>doc utilisateur</u> en anglais pour tous les Addins.

## ------------------------
## Release 2.3.4 - 18/03/2026 
Patchs correctifs :  
<u>Gestionnaire d'affichage</u> : Meilleure gestion des dossiers, des images Raster lors de l'écriture du fichier de 
paramétrage et lors de l'application des règles du fichier.  
<u>Gestion de la fenêtre contenu</u> : Tient maintenant compte de la couche "Image" des dossiers Raster.  
<u>Jeux d'attributs</u> : Mise à jour du fichier de paramétrage par ODG.

## ------------------------
## Release 2.3.3 - 25/02/2026
### 1. Nouvelles fonctionalités
<u>Gestion de la fenêtre contenu</u> : ajout d'une option au menu (clic droit sur le nom de la carte), 
de boutons dans la barre Inca, afin de cocher/décocher rapidement l'ensemble des dossiers et couches 
aussi bien en affichage, édition ou sélection.

### 2. Corrections et Améliorations  
<u>Gestionnaire d'affichage</u> : Possibilité de gérer les dossiers des mosaïques raster  

## ------------------------
## Release 2.3.2 - 06/02/2026
Patchs correctifs :  
<u>Outil de création des parapets</u> : Affichage des erreurs en cas d'exception dans le traitement INCA (Amelio 2025051360)  

<u>Transtypage</u> : Suppression du raccourci (si un raccourci est défini dans le code, 
impossible de le modifier depuis l'application de manière interactive) (Amelio 2025111858)

<u>Queue d'édition</u> : correction bug lors de la remise à zéro du compteur quand la queue est vide (Amelio 2025111911)  

<u>Attribut Visu25k</u> : correction regression lors du remplissage du champ "VISU" quand la valeur est nulle (Amelio 2025111854)  

<u>Outils d'édition souligné et encadré</u> : correction sur le nom des outils dans le panneau de config des raccourcis (Amelio 2025112043)

<u>Jeux d'attributs</u> : (Amelio 2025112041) (redmine 20712)

- refonte du code pour pouvoir avoir les icones chargées à l'ouverture d'un projet
- correction d'un bug dans la possibilité de 'retour en arrière' 
sur une action de modification (CTRL+Z) 
- possibilité de recliquer sur une action du menu déroulant sans sortir de la fenêtre

## Release 2.3.1 - 17/11/2025
Patch correctif :  
<u>Gestionnaire de requêtes</u> : Correction mauvaise gestion des annotations dans la gestion du message sortant (Amelio 2025111216) 

## release 2.3.0 - 06/11/2025

### 1. Nouvelles fonctionalités
  * Gestion de la compatibilité avec l’addin de l’espace collaboratif
  * Prise en compte de OneDrive pour la localisation du fichier de log et 
  recherche du fichier de configuration LoggerUtils.cs directement dans les addins
  * Ajout d'un batch setup.bat pour créer automatiquement des distributions des outils

### 2. Corrections et Améliorations
 * Outil réintégration : 
    * ajout d'un suivi de l'avancement dans le dockpane (Amelio 2025091761)
    * gestion erreur "version est en cours de réconciliation dans une autre application"
  * Gestionnaire de requêtes : 
    * Ajout d'un encart texte pour l'affichage du résultat de la requête. (Amelio 2025100187)
    * gestion des dossiers/ss_dossiers dans l'arborensce de la carte (Amelio 2025100187)
  * Outil souligné touristique : 
    * Mise à niveau de l'outil : cas d'un toponyme concaténé (F25) 
dont le texte est sur une ligne mais la géométrie multiparties n'était pas géré. (Amelio_2025082552)
    * suite à la gestion par mots, ajout d'une exception pour les toponymes courbes. On ne trace qu'un seul souligné, qui sera replacé par les opérateurs.
  * Outil création des terrains de foot et création des points cotés :
    * Gestion des couches "fantômes" pour éviter le message d'erreur (Amelio_2025090191)

## ------------------------
## Release 2.2.2 - 29/08/2025

Correction sur l'outil de remplissage du champs d'affichage (VISU_25K) pour que les modifications soient gardées lors 
de la réintégration.
Suite Amelio 2025082730.


## Release 2.2.1 - 07/08/2025

Correction des 2 executables. 
Nouvelle publication de ConcatAnnoProCoreHostAPI.exe et ExportAnnoProCoreHostAPI.exe suite problème SCAN_DEF


## Release 2.2.0 - 26/06/2025

### 1. Nouvelles fonctionalités
  * Plusieurs boutons de création rapide d'objets :  
	- Symbolisation des terrains de foot,
	- Création de point côté et côte associée,
	- Remplissage du champ VISU_25 en automatique (Vrai ou faux)

  * Plusieurs boutons de création rapide d'objets :  
      - Vider les sélections sur toutes les cartes
      - Activer/Désactiver la mise à jour de l'affichage

  * Version flottante de la barre d'accès rapide avec des boutons définis (x9)

  * Outil réintégration : suivi de l'historique des réintégrations

  * Queue d'édition :  
    - Ajout d'un bouton supprimer l'objet courant dans l'interface + actif avec la touche SUPPR,
    - Ajout de raccourcis clavier sur les boutons de parcours, (Redmine Evolution #20734)
    - Ajout du zoom sur l'objet (Redmine Evolution #20991)
    - Ajout de l'option de tri selon un champ pour les sélections à classe unique (Redmine Evolution #20991)

  * Jeux d'attributs : création de l'outil jeux d'attributs pour faciliter le remplissage instantané de plusieurs champs
    (par exemple SYMBO, COMMENT, …) (Suivi Redmine Evolution #20712).


### 2. Corrections et Améliorations
  * Refonte du code pour l'organisation des Addins.
  * Gestionnaire de requêtes : Meilleure gestion de la création de la gdb REQ.gdb
  * Queue d'édition : 
    * Revue des tests d'existence des objets lors du parcours de la queue d'édition  
      => amélioration significative des temps de parcours
    * Ajout d'info bulles et modification du bouton supprimer (image bouton DEL)
    * Ajout d'une option de tri de la table si une seule classe n'est sélectionnée
  * Outil de changement de côté du décalage:  
    * correction d'un problème de disparition des tronçons de longueur
    inférieure au seuil d'accroche aux extrémités
  * Outil parapets :
    * prise en compte de l'état de la session d edition
  * remise à zéro de l'outil Google et MapView après utilisation  (outil sélection)
  * Outil de transtypage: filtrage des bases de données invalides ou de type autre que géodatabase 


