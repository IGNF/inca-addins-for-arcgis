

# IncaProSDK

Dans le cadre du projet INCA, la Solution **[IncaProSDK.sln](http://gitlab.ign.fr/inca/inca-sdk-pro/blob/develop/code/IncaProSDK.sln)** a été conçue pour développer une collection d'applications (Console Application, Add-in) permettant d’interagir avec ArcGIS Pro via le SDK (.Net)


```
Language:              C#
Subject:               ArcGIS Pro SDK API's
Project:               INCA
Contributor:           INCA Project Team
Organization:          IGN France
Date de mise-à-jour:   07/10/2025
ArcGIS Pro:            3.1.2
Visual Studio:         2022 (v17.6.4)
.NET Target Framework: 6.0
```


### ***Prérequis***

 - ArcGIS Pro 3.1.2 ou + doit être installé
 - Visual Studio 2022 (community ou enterprise) .NET Framework 6.0 doit être installé
 - [*FACULTATIF*] Les Extensions `ArcGIS Pro SDK for .NET` et `ArcGIS Pro SDK for .NET (Utilities)` pour Visual Studio ajoutent des templates et d'autres outils qui facilitent la création des Add-ins SDK Pro ou des Applications CoreHost ArcGIS Pro, parmi d'autres, à partir de zéro.


----------
## 1. **IncaProSDK (Library)**
C'est la [librairie](http://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/lib/IncaProSDK%20%28Library%29) dans laquelle on définit les méthodes qui interagissent avec le SDK Pro directement. Elle est divisée notamment en 3 parties ou layers :

 - **BLL** : Dossier/namespace qui contient les classes définissant la logique et comportement du projet INCA - ArcGIS Pro SDK orientées à des applications de type Console ou Add-Ins.
 - **DAL** : Dossier/namespace qui contient l'ensemble d'objets définissant le modèle de données du projet INCA - ArcGIS Pro SDK. Quelques objets peuvent également apporter des méthodes qui aident à la lecture, définition ou comportement spécifiques au SDK d'ArcGIS Pro.
 - **Commons** : Dossier/namespace qui contient l'ensemble d'outils communs et génériques au projet INCA - ArcGIS Pro SDK.

### Dépendances
 - Lib **Newtonsoft.Json** (version *13.0.3*)
 - Lib **EPPlus** (version *6.2.8*)
 - Lib **Microsoft.IO.RecyclableMemoryStream** (version *2.2.1*)
 - Lib **System.ComponentModel.Annotations** (version *5.0.0*)
 - Lib **log4net** (version *3.1.0*)

>
> **NOTE** : faire **TRES ATTENTION** aux versions de chaque dépendance qu'on a répertorié dans ce document, on ne garantit pas que les outils du `sdk-inca-pro` fonctionneront correctement si vous décidez d'utiliser d'autres versions, tester rigoureusement à chaque montée de version.


----------

## 2. Core Host API's 
Projets de type "**ArcGIS Pro CoreHost Application**" permettant de communiquer avec l'assembly **ArcGIS.Core.dll** du SDK for .NET d'ArcGIS Pro à partir du code Python (ou autre si besoin).

## 2.1 **ConcatAnnoProCoreHostAPI**

Le projet (exécutable) [ConcatAnnoProCoreHostAPI](https://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/corehost/ConcatAnnoProCoreHostAPI) concatène des toponymes lettre-à-lettre dans une seule annotation et l'insère dans une Annotation Feature Class.

### Dépendances
 - [IncaProSDK (Library)](https://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/lib/IncaProSDK%20%28Library%29)


## 2.2 **ExportAnnoProCoreHostAPI**

Le projet (exécutable) [ExportAnnoProCoreHostAPI](https://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/corehost/ExportAnnoProCoreHostAPI) exporte des annotations générées à partir d'ArcGIS PRO et les exporte dans 2 Feature Classes (une pour les annotations DROITES et une autre pour les COURBES) ayant la même structure que les annotations mais toujours de type POINT, le but est de créer des annotations simples, pas complexes : soit droites, soit lettre-à-lettre.

### Dépendances
 - [IncaProSDK (Library)](https://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/lib/IncaProSDK%20%28Library%29)

----------
## 3. Add-Ins :

## 3.1 **IgnMaster**
Projet de type Add-in permettant à tous les Add-Ins suivants d'afficher des ressources dans un onglet commun au niveau du ruban d'ArcGIS Pro. Cet Add-in doit impérativement être installé avec les autres.

## 3.1 **MaplexEngineConfigAddIn**
Projet de type Add-in destiné à configurer automatiquement le moteur Maplex d'ArcGIS Pro. Cet [Add-in](http://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/addin/MaplexEngineConfigAddIn) prend en entrée un fichier Excel correctement paramétré, le parcourt et en fonction des valeurs définies, configure les différentes options du moteur Maplex.

### Dépendances

 - [IncaProSDK (Library)](https://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/lib/IncaProSDK%20%28Library%29)
 - Lib **Microsoft.Xaml.Behaviors.Wpf** (version *1.1.39*)

## 3.2 **IncaDisplay**
Projet de type Add-in permettant à l'utilisateur d'interagir avec la carte sélectionnée (différentes couches) à travers plusieurs outils ayant pour but d'optimiser la productivité.
   
   *&emsp;<u>AttributeSets</u> type Add-in : outil permettant de modifier à la volée plusieurs champs d'une même objet, le tout étant défini dans un fichier xml.
   
   *&emsp;<u>DisplayManager</u> type Add-in : outil permettant d'enregistrer ou d'appliquer des options d'affichage, de modification et de sélection sur les couches d'une carte. paramétrable via un fichier xlsx
   
   *&emsp;<u>DisplayTools</u>  divers outils permettant une manipulation plus aisée d'ArcGIS
		- un outil pour l'activation/pause de l'affichage sur toutes les cartes ouvertes.
		- un outil pour ouvrir une page Google StreetView ou Satellite dans un navigateur web
		- un outil pour vider la sélection de toutes les cartes
		- un panneau contenant les 9 outils les plus utilisés
   
   *&emsp;<u>EditQueue</u>  type Add-in : outil permettant de parcourir une table, préenregistrée, d'éléments de différentes classes
   
   *&emsp;<u>QueryManager</u>  type Add-in : outil permettant de gérer les sélection via des tables préenregistrées. Les sélections peuvent être enregistrées dans des tables pour ensuite être parcourues dans la queue d'édition.
   
### Dépendances

- [IncaProSDK (Library)](https://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/lib/IncaProSDK%20%28Library%29)
 - Librairie **Microsoft.Xaml.Behaviors.Wpf** (version *1.1.39*)




## 3.3 **IncaEditing**
Projet de type Add-in présentant des outils d'édition complémentaires tels que:
   
   *&emsp;<u>CastFeatures</u>  : outil de transtypage permettant de transférer des entités d'une classe à une autre, en respectant des règles définies dans un fichier Excel de configuration.
   
   *&emsp;<u>ExportSymbols</u>  : outil d'export des symboles contenus dans des couches d'entités vers un fichier de styles (.stylx)
   
   *&emsp;<u>FeatureEdit</u>  divers outils d'édition permettant une manipulation plus aisée d'ArcGIS :
		- un outil pour la cration des parapets des ponts
		- un outil pour remplir l'attribut de visualisation d'un clic
		- un outil de création du rond central et ligne médianes des terrainsde foot
		- un outil de création des points côté	
   
   *&emsp;<u>OffsetSide</u>  : outil permettant de changer de côté de décalage

### Dépendances

 - [IncaProSDK (Library)](https://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/lib/IncaProSDK%20%28Library%29)
 - Librairie **Microsoft.Xaml.Behaviors.Wpf** (version *1.1.39*)
 - Librairie **Newtonsoft.Json** (version *13.0.3*)



## 3.4 **IncaReintegration**
Projet de type Add-In permettant la réintégration des données d'une géodatabase fichier d'extraction vers la géodatabase partagée.
Il permet aussi de lancer l'ouverture de la console de résolution de conflits en présence de conflits


### Dépendances

 - [IncaProSDK (Library)](https://gitlab.ign.fr/inca/inca-sdk-pro/tree/develop/code/lib/IncaProSDK%20%28Library%29)
 - Librairie **Microsoft.Xaml.Behaviors.Wpf** (version *1.1.39*)



>  
>
> **NOTE** : faire **TRES ATTENTION** aux versions de chaque dépendance qu'on a répertorié dans ce document, on ne garantit pas que les outils du `sdk-inca-pro` fonctionneront correctement si vous décidez d'utiliser d'autres versions, tester rigoureusement à chaque montée de version.

----------

> # **Mode d'emploi**
>
>
> ### Installation utilisateur
>
>  1. Télécharger la version (.zip) qui vous intéresse à partir de l'URL officielle des livrables https://gitlab.ign.fr/inca/inca-sdk-pro/tree/master/releases
>  2. Dézipper où vous le souhaitez le fichier téléchargé
>  3. Exécuter le fichier `user_install.bat` en tant qu'administrateur. Celui-ci va copier automatiquement tous les fichiers du répertoire `\bin_inca_sdk` dans le dossier `\bin` d'ArcGIS Pro : `ARCGIS_PRO_INSTALL_DIRECTORY\bin\bin_inca\sdk` (**Exemple** : *C:\Program Files\ArcGIS\Pro\bin\bin_inca\sdk*) et va installer tous les add-ins disponibles dans le répertoire `\add-ins`
>  
>
> **Note** : si les `.dll`'s et le fichier `ConsoleArcGISProSDKIncaAPI.exe` ne sont pas détectés lors de son exécution => vérifier que le chemin du dossier `\bin` d'ArcGIS Pro se trouve bien dans la variable d'envieonnement `PATH` de System.
>
> <br></br>
> ### Installation développeur
> 1. Récupérer le code à partir du `repository` [https://gitlab.ign.fr/inca/inca-sdk-pro](ssh://git@gitlab.ign.fr:10022/inca/inca-sdk-pro.git_ne_fonctionne_plus_???_à_vérifier)
>
> **Note** : Toujours utiliser la branche `develop`
> 
> 2. La première fois toutes les `références d'ArcGIS Pro et librairies externes` seront cassées.
>  - Pour réparer les références des librairies ArcGIS : clic droit sur chaque projet > clic sur l'option `Pro Fix References` > clic sur le bouton `OK` > clic sur le bouton `Reload All`
>  -  Pour réparer les références des librairies externes il faut passer par le NuGet Packages Manager : clic droit sur la solution > `Manage NuGet Packages for solution...` et télécharger.
>  
> ***Astuce*** : le plus simple est de désinstaller d'abord les packages, puis de les installer à nouveau.
> 
> 3. `Clean Solution` et `Build Solution`, la compilation doit être réussie
>
> ***Astuce*** : afin d'éviter des problèmes lorsqu'on fait une nouvelle installation, veuillez supprimer tous les fichiers qui ont été copiés lors de l'installation précédente dans le dossier `\bin\bin_inca\sdk` d'ArcGIS Pro car lorsque ArcGIS Pro est lancé, il initialise tout ce qu'il trouve dans le dossier `\bin` où ArcGIS Pro a été installé.
>
> <br></br>
> ### Création automatique d'une distribution (développeur)
> 1. Ouvrir dans un éditeur de texte le fichier setup.bat situé à la racine du dossier inca-sdk-pro
> 2. Modififier le nom du fichier d'installation à créer (variable OUTPUT_FILE_NAME)
> 3. Double-cliquer sur le fichier setup.bat pour l'exécuter
> 4. Retrouver le fichier zippé d'installation dans le dossier releases
>
> ### Création manuelle d'une distribution (développeur)
> 1. Compiler l'ensemble de la solution en mode *Release*
> 2. Publier les projets ConcatAnnoProCoreHostAPI et ExportAnnoProCoreHostAPI pour obtenir des fichiers .exe auto-suffisants en sortie: clic droit sur chaque projet > clic sur l'option `Publish`
> 3. Recopier dans un répertoire le script d'installation, les addins et dll compilés, les fichiers exécutables publiés juste avant, ainsi que les dll dont dépendent les outils, en se basant sur la structure des publications les plus récentes.
> 4. Zipper le répertoire qui sera distribué en l'état