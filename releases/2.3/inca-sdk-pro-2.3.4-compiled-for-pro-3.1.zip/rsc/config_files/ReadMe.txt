#######################################
# 		Config file (TEMPLATE)		  #
#######################################

Le fichier "maplex_engine_config_file_TEMPLATE.xlsx" contient quelques exemples de paramétrage afin de guider un peu mieux à l'utilisateur qui se sert de l'outil pour la première fois.


			------------
			--- NOTE ---
			------------
Etant donné que l'outil commence à lire les valeurs renseignées juste après les noms de colonnes, les 2 premiers colonnes avant les exemples de paramétrage (les types de données et la ligne noire) doivent être éffacées si vous voulez adapter ce template dans un environnement de production. Si vous ne le faites pas l'outil marchera de toutes façons mais il va enregistrer des erreurs futiles dans le fichier de logs.


###########################################
#  Query.gdb   (Pour le gestionnaire de requêtes )  #
###########################################

La gdb contient les tables qui sont lues pour utiliser le gestionnaire de requêtes.
-> à ajouter aux géodatabases de son projet.