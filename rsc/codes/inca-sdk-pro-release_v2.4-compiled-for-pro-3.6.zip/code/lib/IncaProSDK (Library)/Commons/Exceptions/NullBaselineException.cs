﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace IGN.Inca.ArcGISPro.SDK.Commons.Exceptions
{
    /// <summary>
    /// Exception when a baseline is missing for a Feature Annotation
    /// </summary>
    public class NullBaselineException : Exception
    {
        /// <summary>
        /// Just create the exception
        /// </summary>
        public NullBaselineException()
          : base()
        {
        }

        /// <summary>
        /// Create the exception with description
        /// </summary>
        /// <param name="message">Exception description</param>
        public NullBaselineException(String message)
          : base(message)
        {
        }

        /// <summary>
        /// Create the exception with description and inner cause
        /// </summary>
        /// <param name="message">Exception description</param>
        /// <param name="innerException">Exception inner cause</param>
        public NullBaselineException(String message, Exception innerException)
          : base(message, innerException)
        {
        }
    }
}
